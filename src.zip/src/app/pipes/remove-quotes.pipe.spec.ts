import { RemoveQuotesPipe } from './remove-quotes.pipe';

describe('RemoveQuotesPipe', () => {
  it('create an instance', () => {
    const pipe = new RemoveQuotesPipe();
    expect(pipe).toBeTruthy();
  });
});
