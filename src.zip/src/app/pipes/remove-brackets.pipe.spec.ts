import { RemoveBracketsPipe } from './remove-brackets.pipe';

describe('RemoveBracketsPipe', () => {
  it('create an instance', () => {
    const pipe = new RemoveBracketsPipe();
    expect(pipe).toBeTruthy();
  });
});
