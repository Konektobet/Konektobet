// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBbvvieLFodTlOAU6cnQvSUP3SqEUOdgSc",
  authDomain: "konektobet-b470a.firebaseapp.com",
  projectId: "konektobet-b470a",
  storageBucket: "konektobet-b470a.appspot.com",
  messagingSenderId: "98813304540",
  appId: "1:98813304540:web:adf7d3144aa03513d7de19"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);