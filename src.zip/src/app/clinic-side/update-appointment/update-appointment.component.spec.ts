import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { SupabaseService } from 'src/app/service/supabase.service';

@Component({
  selector: 'app-update-appointment',
  templateUrl: './update-appointment.component.html',
  styleUrls: ['./update-appointment.component.scss']
})
export class UpdateAppointmentComponent implements OnInit {
  clinic: any;

  constructor(
    public dialogRef: MatDialogRef<UpdateAppointmentComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private supabaseService: SupabaseService
  ) {
    this.clinic = data.clinic;
  }

  ngOnInit(): void {
    this.fetchAppointmentDetails();
  }

  async fetchAppointmentDetails() {
    try {
      // Fetch user's firstname
      const { data: userFirstNameData, error: userFirstNameError } =
        await this.supabaseService
          .getSupabase()
          .from('users_tbl')
          .select('firstname')
          .eq('id', this.clinic.aUsers_id);

      // Fetch user's lastname
      const { data: userLastNameData, error: userLastNameError } =
        await this.supabaseService
          .getSupabase()
          .from('users_tbl')
          .select('lastname')
          .eq('id', this.clinic.aUsers_id);

      if (userFirstNameError || userLastNameError) {
        console.error('Error fetching user data:', userFirstNameError || userLastNameError);
      } else {
        // Update the clinic with user's firstname and lastname
        this.clinic.firstname = userFirstNameData[0]?.firstname;
        this.clinic.lastname = userLastNameData[0]?.lastname;
      }
    } catch (error) {
      console.error('Error fetching appointment details:', error);
    }
  }

  updateAppointment() {
    // Implement update appointment logic here
  }

  getStatusColorClass(status: string): string {
    switch (status) {
      case 'Your appointment status is pending':
        return 'yellow-status';
      case 'Your Appointment has been approved':
        return 'green-status';
      case 'Your Appointment is Cancelled':
        return 'red-status';
      default:
        return '';
    }
  }
}
