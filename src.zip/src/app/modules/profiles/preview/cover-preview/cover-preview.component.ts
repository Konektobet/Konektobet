import { Component } from '@angular/core';

@Component({
  selector: 'app-cover-preview',
  templateUrl: './cover-preview.component.html',
  styleUrls: ['./cover-preview.component.scss']
})
export class CoverPreviewComponent {

}
