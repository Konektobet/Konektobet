export const environment = {
    production: false,
    firebase: {
        apiKey: "AIzaSyAEE4oLk-ZjKkUe0mf5IX9sRivELLkCTVM",
        authDomain: "konektobetapp.firebaseapp.com",
        databaseURL: "https://konektobetapp-default-rtdb.firebaseio.com",
        projectId: "konektobetapp",
        storageBucket: "konektobetapp.appspot.com",
        messagingSenderId: "311489632374",
        appId: "1:311489632374:web:8bfb677bfe9eabb7ae6757"
    },
};