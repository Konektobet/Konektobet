import { Component, OnInit } from '@angular/core';
import { SupabaseService } from 'src/app/service/supabase.service';
import { MatDialog } from '@angular/material/dialog';
import { AppointmentUpdateComponent } from '../appointment-update/appointment-update.component';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.scss']
})
export class AppointmentComponent implements OnInit {
  appointments: any[] = [];
  appointment: any;

  constructor(
    private supabaseService: SupabaseService,
    private dialog: MatDialog,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.fetchAppointments();
  }

  async fetchAppointments() {
    try {
      const currentUser = this.supabaseService.getAuthStateSnapshot();
      
      if (currentUser) {
        const { data: userData, error: userError } = await this.supabaseService
          .getSupabase()
          .from('users_tbl')
          .select('id')
          .eq('email', currentUser.email);

        if (userError) {
          console.error('Error fetching user data:', userError);
        } else {
          if (userData && userData.length > 0) {
            const userId = userData[0].id;

            const { data: appointmentsData, error: appointmentsError } =
              await this.supabaseService
                .getSupabase()
                .from('appointment_tbl')
                .select('*')
                .eq('aUsers_id', userId);

            if (appointmentsError) {
              console.error('Error fetching appointments:', appointmentsError);
            } else {
              this.appointments = appointmentsData || [];
            }
          } else {
            console.error('No user data found for the logged-in user.');
          }
        }
      } else {
        console.warn('No logged-in user found.');
      }
    } catch (error) {
      console.error('Error:', error);
    }
  }

  getStatusColorClass(status: string): string {
    switch (status) {
      case 'Your appointment status is pending':
        return 'yellow-status';
      case 'Your Appointment has been approved':
        return 'green-status';
      case 'Your Appointment is Cancelled':
        return 'red-status';
      default:
        return '';
    }
  }

  openUpdateAppointment(appointmentId: string): void {
    const dialogRef = this.dialog.open(AppointmentUpdateComponent, {
      width: '500px',
      height: 'auto',
      data: { appointmentId }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log('The update appointment dialog was closed');
    });
  }
  
  isAppointmentPending(status: string): boolean {
    return status === 'Your appointment status is pending';
  }

  async deleteAppointment(appointmentId: string) {
    try {
      const isConfirmed = await Swal.fire({
        title: 'Are you sure?',
        text: 'You will not be able to recover this appointment!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3f51b5',
        confirmButtonText: 'Yes, delete it!'
      });
  
      if (isConfirmed.isConfirmed) {
        await this.deleteAppointmentFromDatabase(appointmentId);
      }
    } catch (error) {
      console.error('Error deleting appointment:', error);
      Swal.fire(
        'Error!',
        'An error occurred while deleting the appointment.',
        'error'
      );
    }
  }
  
  private async deleteAppointmentFromDatabase(appointmentId: string): Promise<void> {
    try {
      // Delete appointment from 'appointment_tbl' based on the appointment ID
      await this.supabaseService
        .getSupabase()
        .from('appointment_tbl')
        .delete()
        .eq('id', appointmentId);
  
      // Find the index of the appointment in the local array
      const index = this.appointments.findIndex(appointment => appointment.id === appointmentId);
  
      // If the appointment is found in the local array, remove it using splice
      if (index !== -1) {
        this.appointments.splice(index, 1);
      }
  
      Swal.fire({
        icon: 'success',
        title: 'Appointment Deleted Successfully',
        text: 'Your appointment has been deleted.',
      }).then(() => {
        console.log(appointmentId);
      });
    } catch (error) {
      console.error('Error deleting appointment:', error);
      Swal.fire(
        'Error!',
        'An error occurred while deleting the appointment.',
        'error'
      );
    }
  }

  // deleteAppointment(appointment: any): void {
  //   // Use SweetAlert to confirm deletion
  //   Swal.fire({
  //     title: 'Cancel this appointment?',
  //     text: "You won't be able to revert this!",
  //     icon: 'warning',
  //     showCancelButton: true,
  //     confirmButtonColor: '#d33',
  //     cancelButtonColor: '#3f51b5',
  //     confirmButtonText: 'Yes, cancel it!',
  //   }).then((result) => {
  //     if (result.isConfirmed) {
  //       // Remove appointment from the local array
  //       const index = this.appointments.findIndex((c) => c.id === appointment.id);
  //       if (index !== -1) {
  //         this.appointments.splice(index, 1);
  //       }

  //       // Delete appointment from the database
  //       this.deleteAppointmentFromDatabase(appointment.id);
  //     }
  //   });
  // }
  
  // private async deleteAppointmentFromDatabase(appointmentId: string): Promise<void> {
  //   try {
  //     // Delete clinic from 'clinic_tbl' based on the clinic ID
  //     const { error: deleteError } = await this.supabaseService
  //       .getSupabase()
  //       .from('appointment_tbl')
  //       .delete()
  //       .eq('id', appointmentId);
  //       console.log(appointmentId)

  //     if (deleteError) {
  //       console.error('Error deleting clinic:', deleteError);
  //       // Handle error appropriately
  //     } else {
  //       Swal.fire({
  //         icon: 'success',
  //         title: 'Appointment Cancelled Successfully',
  //         text: 'The appointment has been cancelled.',
  //       });

  //       // await this.generateRecommendations();
  //     }
  //   } catch (error) {
  //     console.error('Error:', error);
  //     // Handle error appropriately
  //   }
  // }
}
