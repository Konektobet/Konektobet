import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ClinicRoutingModule } from './clinic-routing.module';
import { ClinicComponent } from './clinic.component';

import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { ClinicDetailsComponent } from '../details/clinic-details/clinic-details.component';

@NgModule({
  declarations: [
    ClinicComponent,
    ClinicDetailsComponent
  ],
  imports: [
    CommonModule,
    ClinicRoutingModule,

    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatDividerModule,
  ]
})
export class ClinicModule { }
