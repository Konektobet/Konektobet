import { ENTER, COMMA } from '@angular/cdk/keycodes';
import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { Session } from '@supabase/supabase-js';
import { BehaviorSubject, Observable, map, startWith } from 'rxjs';
import { SupabaseService } from 'src/app/service/supabase.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-trial',
  templateUrl: './trial.component.html',
  styleUrls: ['./trial.component.scss']
})
export class TrialComponent {
  serviceControl = new FormControl();
  // healthcareControl = new FormControl();
  scheduleControl = new FormControl();

  user: Session | null = null;
  clinicForm!: FormGroup;

  separatorKeysCodes: number[] = [ENTER, COMMA];
  selectedServices: string[] = [];
  // selectedHealthcares: string[] = [];
  selectedSchedules: string[] = [];

  private servicesSubject = new BehaviorSubject<string[]>([
    'Confinement',
    'Boarding',
    'Grooming',
    'Pet Supply',
    'Home Service',
    'Deworming',

    'CBC',
    'Blood Chemistry',
    'PCR Test',
    'Treatment',
    'Vaccination',
    'Surgery',
    'Teeth Cleaning',
    'Lab Tests',
    'Ultrasound',
    'Digital Xray',
  ]);

  private schedulesSubject = new BehaviorSubject<string[]>([
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ]);

  filteredServices: Observable<string[]> | undefined;
  filteredSchedules: Observable<string[]> | undefined;

  services$: Observable<string[]> = this.servicesSubject.asObservable();
  schedule$: Observable<string[]> = this.schedulesSubject.asObservable();

  services: string[] = [
    'Confinement',
    'Boarding',
    'Grooming',
    'Pet Supply',
    'Home Service',
    'Deworming',

    'CBC',
    'Blood Chemistry',
    'PCR Test',
    'Treatment',
    'Vaccination',
    'Surgery',
    'Teeth Cleaning',
    'Lab Tests',
    'Ultrasound',
    'Digital Xray',
  ];

  schedules: string[] = [
    'Monday',
    'Tuesday',
    'Wednesday',
    'Thursday',
    'Friday',
    'Saturday',
    'Sunday',
  ];

  dialogRef: any;
  toppings = new FormControl('');

  toppingList: string[] = ['Extra cheese', 'Mushroom', 'Onion', 'Pepperoni', 'Sausage', 'Tomato'];
  constructor(
    private formBuilder: FormBuilder,
    private supabaseService: SupabaseService
  ) {}
  ngOnInit(): void {
    this.clinicForm = this.formBuilder.group({
      cName: ['', Validators.required],
      cAddress: ['', Validators.required],
      cNumber: ['', Validators.required],
      cEmail: ['', Validators.required],
      cVet: ['', Validators.required],
      cLink: ['', Validators.required],
      cPrice: ['', Validators.required],
      cTime: ['', Validators.required],
      cService: [''],
      // cHealthcare: [''],
      cSchedule: [''],
    });

    this.filteredServices = this.serviceControl.valueChanges.pipe(
      startWith(''),
      map((value) => this.filterServices(value || ''))
    );

    this.filteredSchedules = this.scheduleControl.valueChanges.pipe(
      startWith(''),
      map((value) => this.filterSchedules(value || ''))
    );
  }

  addService(event: MatAutocompleteSelectedEvent): void {
    const selectedService = event.option.viewValue;
    this.selectedServices.push(selectedService);
    this.serviceControl.setValue('');

    // Update the available services in real-time
    this.servicesSubject.next(this.servicesSubject.value.filter((service) => service !== selectedService));
  }

  removeService(service: string): void {
    const index = this.selectedServices.indexOf(service);

    if (index >= 0) {
      // Add the removed service back to the list of available services
      this.servicesSubject.next([...this.servicesSubject.value, service]);

      // Remove the service from the selected services
      this.selectedServices.splice(index, 1);
    }
  }

  filterServices(value: string): string[] {
    const filterValue = this.normalizeValue(value);
    return this.servicesSubject.value.filter((service) =>
      this.normalizeValue(service).includes(filterValue)
    );
  }

  addSchedule(event: MatAutocompleteSelectedEvent): void {
    const selectedSchedule = event.option.viewValue;
    this.selectedSchedules.push(selectedSchedule);
    this.scheduleControl.setValue('');

     // Update the available services in real-time
     this.schedulesSubject.next(this.schedulesSubject.value.filter((schedule) => schedule !== selectedSchedule));
  }

  removeSchedule(schedule: string): void {
    const index = this.selectedSchedules.indexOf(schedule);

    if (index >= 0) {
      // Add the removed service back to the list of available services
      this.schedulesSubject.next([...this.schedulesSubject.value, schedule]);

      this.selectedSchedules.splice(index, 1);
    }
  }

  filterSchedules(value: string): string[] {
    const filterValue = this.normalizeValue(value);
    return this.schedulesSubject.value.filter((schedule) =>
      this.normalizeValue(schedule).includes(filterValue)
    );
  }

  private normalizeValue(value: string): string {
    return value.toLowerCase().replace(/\s/g, '');
  }

  // private clearNewClinic() {
  //   this.clinicForm.reset();
  //   this.selectedServices = [];
  //   // this.selectedHealthcares = [];
  //   this.selectedSchedules = [];

  //   this.services = [
  //     'Confinement',
  //     'Boarding',
  //     'Grooming',
  //     'Pet Supply',
  //     'Home Service',
  //     'Deworming',

  //     'CBC',
  //     'Blood Chemistry',
  //     'PCR Test',
  //     'Treatment',
  //     'Vaccination',
  //     'Surgery',
  //     'Teeth Cleaning',
  //     'Lab Tests',
  //     'Ultrasound',
  //     'Digital Xray',
  //   ];

  //   // this.healthcares = [
  //   //   'CBC',
  //   //   'Blood Chemistry',
  //   //   'PCR Test',
  //   //   'Treatment',
  //   //   'Vaccination',
  //   //   'Surgery',
  //   //   'Teeth Cleaning',
  //   //   'Lab Tests',
  //   //   'Ultrasound',
  //   //   'Digital Xray',
  //   // ];

  //   this.schedules = [
  //     'Monday',
  //     'Tuesday',
  //     'Wednesday',
  //     'Thursday',
  //     'Friday',
  //     'Saturday',
  //     'Sunday',
  //   ];
  // }
}
