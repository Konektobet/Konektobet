import { Component } from '@angular/core';

@Component({
  selector: 'app-found-clinic',
  templateUrl: './found-clinic.component.html',
  styleUrls: ['./found-clinic.component.scss']
})
export class FoundClinicComponent {

}
